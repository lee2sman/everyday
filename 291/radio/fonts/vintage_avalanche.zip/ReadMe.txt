
This font is made by APlaPi.
You MUST NOT sell, rent, license or redistribute the font without my explicit permission.
If you need a license feel free to ask. For any other information e-mail me at abrahamplapi@gmail.com

 - --  Donations will be welcome and very much appreciated.  -- -

Thank you
APlaPi
